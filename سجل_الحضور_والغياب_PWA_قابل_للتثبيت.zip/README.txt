سجل الحضور والغياب — نسخة PWA قابلة للتثبيت

هذه النسخة تحتوي على manifest + service worker + تسجيل service worker، لتكون قابلة للتثبيت كتطبيق على Android عندما يستوفي المتصفح شروط التثبيت.

للتثبيت على Android: افتح الرابط في Google Chrome مباشرة، ثم من قائمة ⋮ ابحث عن Install app أو Add to Home screen.
